const mysql = require('mysql');

    const connection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'gestion_location'
    });
    
    connection.connect((err) => {
        if (err) return console.error(err.message);
      
        let sql = 'SELECT * FROM appartements WHERE 1';
      
        connection.query(sql, [true], (error, results) => {
          if (error) return console.error(error.message);
          console.log(results);
        });
      });