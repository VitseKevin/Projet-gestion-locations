class Demande {
    constructor(id,typeDem,dateLimite) {
        this.id = id;
        this.typeDem = typeDem;
        this.dateLimite = dateLimite;
        
    }
}

