class Client extends Personne {
    visiter(){

    }
    demander(){
        
    }
}