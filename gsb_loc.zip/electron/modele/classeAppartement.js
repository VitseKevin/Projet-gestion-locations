class Appartement {
    constructor(rue,arrondissement,etage,typeApp,prixLoc,prixCharges,ascenceur,preavis,dateLibre) {
        this.id = id;
        this.rue = rue;
        this.arrondissement = arrondissement;
        this.etage = etage;
        this.typeApp = typeApp;
        this.prixLoc = prixLoc;
        this.prixCharges = prixCharges ;
        this.ascenceur = ascenceur;
        this.preavis = preavis;
        this.dateLibre = dateLibre;
    }

    ajouterAppartement(){

    }
}