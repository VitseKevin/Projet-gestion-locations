class Proprietaire extends Personne {
    posseder(){

    }
}